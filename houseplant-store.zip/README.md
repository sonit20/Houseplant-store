# 🌿 Green Haven - Houseplant Store

This is a React + Redux shopping cart project built as a final submission for the JavaScript course on Coursera. It includes Redux integration, routing, a product listing page, a cart system, and more.

## 🚀 Live Demo

Coming soon (use GitHub Pages or Netlify to deploy)

## 📂 Features

- 🏠 Landing Page with company name, description, background image, and Get Started button.
- 🪴 Product Listing Page:
  - Displays 6 unique houseplants.
  - Grouped by plant types.
  - Each has Add to Cart button that disables once clicked.
- 🛒 Header with:
  - Navigation to both product and cart pages.
  - Cart icon showing total item count.
- 🧺 Shopping Cart Page:
  - Displays selected items with name, image, quantity, and price.
  - Increase/decrease quantity.
  - Remove item.
  - Checkout button ("Coming Soon" message).
  - Continue Shopping button.

## 🛠 Tech Stack

- React
- Redux (Toolkit)
- React Router
- CSS

## 📁 Installation

```bash
git clone https://github.com/yourusername/green-haven.git
cd green-haven
npm install
npm start
```

## 🧪 Evaluation Criteria

| Task | Points |
|------|--------|
| GitHub URL + Code | 6 |
| Landing Page | 5 |
| Product Listing | 9 |
| Header | 7 |
| Cart Page | 23 |
| **Total** | **50** |

## 🧑‍💻 Author

Sonit Chopra – [LinkedIn](https://www.linkedin.com)

---

✅ Ready for peer review and submission!
