import React from 'react';
import { useDispatch } from 'react-redux';
import { increaseQuantity, decreaseQuantity, deleteItem } from '../redux/cartSlice';

function CartItem({ item }) {
  const dispatch = useDispatch();

  return (
    <div style={{ borderBottom: '1px solid #ccc', padding: '1em 0' }}>
      <img src={item.image} alt={item.name} style={{ height: 50 }} />
      <span>{item.name}</span>
      <span>Qty: {item.quantity}</span>
      <span>Price: ₹{item.price}</span>
      <button onClick={() => dispatch(increaseQuantity(item.id))}>+</button>
      <button onClick={() => dispatch(decreaseQuantity(item.id))}>−</button>
      <button onClick={() => dispatch(deleteItem(item.id))}>Delete</button>
    </div>
  );
}

export default CartItem;