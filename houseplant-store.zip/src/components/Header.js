import React from 'react';
import { Link } from 'react-router-dom';
import { useSelector } from 'react-redux';

function Header() {
  const totalItems = useSelector(state => state.cart.totalItems);
  return (
    <header style={{ padding: '1em', background: '#4caf50', color: 'white' }}>
      <nav style={{ display: 'flex', justifyContent: 'space-between' }}>
        <div>
          <Link to="/products" style={{ color: 'white', marginRight: '1em' }}>Products</Link>
          <Link to="/cart" style={{ color: 'white' }}>Cart</Link>
        </div>
        <div>🛒 {totalItems}</div>
      </nav>
    </header>
  );
}

export default Header;