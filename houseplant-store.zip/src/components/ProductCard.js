import React from 'react';
import { useDispatch, useSelector } from 'react-redux';
import { addToCart } from '../redux/cartSlice';

function ProductCard({ plant }) {
  const dispatch = useDispatch();
  const inCart = useSelector(state => state.cart.items.find(item => item.id === plant.id));

  return (
    <div style={{ border: '1px solid #ccc', margin: 10, padding: 10, width: 200 }}>
      <img src={plant.image} alt={plant.name} style={{ width: '100%' }} />
      <h3>{plant.name}</h3>
      <p>₹{plant.price}</p>
      <button disabled={!!inCart} onClick={() => dispatch(addToCart(plant))}>
        {inCart ? 'Added' : 'Add to Cart'}
      </button>
    </div>
  );
}

export default ProductCard;