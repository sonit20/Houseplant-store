import React from 'react';
import { useSelector, useDispatch } from 'react-redux';
import CartItem from '../components/CartItem';
import Header from '../components/Header';
import { useNavigate } from 'react-router-dom';

function CartPage() {
  const cart = useSelector(state => state.cart);
  const navigate = useNavigate();

  return (
    <>
      <Header />
      <h2 style={{ textAlign: 'center' }}>Shopping Cart</h2>
      <div style={{ maxWidth: '800px', margin: '0 auto' }}>
        {cart.items.map(item => (
          <CartItem key={item.id} item={item} />
        ))}
        <h3>Total Items: {cart.totalItems}</h3>
        <h3>Total Price: ₹{cart.totalPrice.toFixed(2)}</h3>
        <button onClick={() => alert('Checkout Coming Soon')}>Checkout</button>
        <button onClick={() => navigate('/products')}>Continue Shopping</button>
      </div>
    </>
  );
}

export default CartPage;