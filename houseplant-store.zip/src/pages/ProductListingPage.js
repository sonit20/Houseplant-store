import React from 'react';
import products from '../products';
import ProductCard from '../components/ProductCard';
import Header from '../components/Header';

function ProductListingPage() {
  return (
    <>
      <Header />
      <h2 style={{ textAlign: 'center' }}>Our Houseplants</h2>
      <div style={{ display: 'flex', flexWrap: 'wrap', justifyContent: 'center' }}>
        {products.map(plant => (
          <ProductCard key={plant.id} plant={plant} />
        ))}
      </div>
    </>
  );
}

export default ProductListingPage;