const products = [
  { id: 1, name: 'Aloe Vera', price: 200, image: 'https://via.placeholder.com/150?text=Aloe+Vera' },
  { id: 2, name: 'Snake Plant', price: 250, image: 'https://via.placeholder.com/150?text=Snake+Plant' },
  { id: 3, name: 'Spider Plant', price: 180, image: 'https://via.placeholder.com/150?text=Spider+Plant' },
  { id: 4, name: 'Peace Lily', price: 300, image: 'https://via.placeholder.com/150?text=Peace+Lily' },
  { id: 5, name: 'Bamboo Palm', price: 350, image: 'https://via.placeholder.com/150?text=Bamboo+Palm' },
  { id: 6, name: 'ZZ Plant', price: 280, image: 'https://via.placeholder.com/150?text=ZZ+Plant' }
];

export default products;